// ═══════════════════════════════════════════════════════════════════════
//  EspFrameData.h  —  Shared-memory layout for External ESP
//
//  THIS HEADER IS INCLUDED BY BOTH NATIVE (writer) AND JAVA (reader).
//
//  ALL screen coordinates are NORMALIZED to 0.0–1.0 so the layout is
//  resolution-independent.  Java multiplies by actual screen pixels to
//  get final draw positions.  This is the "screen-resolution fix".
//
//  SeqLock protocol:
//    Writer: seqWrite |= 1  (odd = write in progress)
//            __sync_synchronize()
//            … copy data …
//            __sync_synchronize()
//            seqWrite = (seqWrite + 1) & ~1  (even = done)
//    Reader: spin while (seqWrite & 1) != 0
//            … read data …
//
//  SHM paths tried (matching Java EspOverlay.java order):
//    1.  /storage/emulated/0/CrashLog/ark_esp_v1
//    2.  externalFilesDir/ark_esp_v1      (Java only, runtime path)
//    3.  filesDir/ark_esp_v1              (Java only, runtime path)
//    4.  /data/local/tmp/ark_esp_v1
// ═══════════════════════════════════════════════════════════════════════
#pragma once
#include <stdint.h>

#define ARK_ESP_MAX_PLAYERS  100
#define ARK_ESP_MAX_VEHICLES  20
#define ARK_ESP_MAX_BONES     17

// ── Per-player data ────────────────────────────────────────────────────
struct ArkEspPlayer {
    // Head and root screen positions — NORMALIZED (0.0–1.0)
    float headX, headY;
    float rootX, rootY;

    // Bone screen positions — NORMALIZED (0.0–1.0)
    // Bone index mapping (same 17 bones as original):
    //  0=neck_01 1=spine_03 2=spine_02 3=spine_01 4=pelvis
    //  5=upperarm_r 6=lowerarm_r 7=hand_r
    //  8=upperarm_l 9=lowerarm_l 10=hand_l
    //  11=thigh_r 12=calf_r 13=foot_r
    //  14=thigh_l 15=calf_l 16=foot_l
    float boneX[ARK_ESP_MAX_BONES];
    float boneY[ARK_ESP_MAX_BONES];
    uint8_t boneValid[ARK_ESP_MAX_BONES];   // 1 = valid bone position
    uint8_t _bone_pad[3];                   // align to 4 bytes — matches Java reader

    float   health;    // 0.0–1.0 (fraction of max; knocked = NearDeathBreath / 100)
    float   distance;  // meters

    uint8_t isBot;
    uint8_t isVisible; // has LOS
    uint8_t isKnocked;
    uint8_t hasArmor;

    char    name[32];  // UTF-8, null-terminated
};

// ── Per-vehicle data ───────────────────────────────────────────────────
struct ArkEspVehicle {
    float   screenX, screenY; // NORMALIZED (0.0–1.0)
    float   distance;         // meters
    uint8_t hasEnemy;         // occupied by an enemy
    uint8_t _veh_pad[3];
    char    name[32];         // UTF-8, null-terminated
};

// ── Frame header + all entity arrays ──────────────────────────────────
struct ArkEspFrame {
    volatile uint32_t seqWrite;  // SeqLock counter (odd=writing, even=done)
    volatile uint32_t seqRead;   // not used by writer, available for future use

    float canvasW, canvasH;      // game canvas size (for debug; coords are normalized)

    int32_t playerCount;
    int32_t vehicleCount;
    int32_t enemyCount;
    int32_t botCount;

    ArkEspPlayer  players[ARK_ESP_MAX_PLAYERS];
    ArkEspVehicle vehicles[ARK_ESP_MAX_VEHICLES];

    int32_t fps;
    char    expiryText[48];   // e.g. "ACCESS VALIDITY 3 DAYS" or "Lifetime"
    uint8_t _end_pad[12];
};

#define ARK_SHM_SIZE  ((int)sizeof(ArkEspFrame))
