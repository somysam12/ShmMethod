package com.bgmi;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Choreographer;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

/**
 * EspOverlay — External ESP overlay (DeadEye rendering UI + ArkExternal coordinate fix)
 *
 * Coordinate fix from ArkExternal:
 *   - Uses actual screenW/screenH (NOT canvas.getWidth/Height)
 *   - Sequential position-based SHM reading (buf.position() + buf.getFloat())
 *   - sw = screenW, sh = screenH — always landscape, set once
 *
 * Rendering: DeadEye-style 3 paints + draw helpers
 * Sizing: mScale = sh / 1080f proportional
 */
@SuppressWarnings({"deprecation", "unused"})
public class EspOverlay extends Service {

    // ── SHM layout (must match EspFrameData.h exactly) ────────────────────
    static final int MAX_PLAYERS  = 100;
    static final int MAX_VEHICLES = 20;
    static final int MAX_BONES    = 17;
    static final int PLAYER_STRIDE  = 216;
    static final int VEHICLE_STRIDE = 48;
    static final int FRAME_HEADER   = 32;
    static final int PLAYERS_OFFSET  = FRAME_HEADER;                                         // 32
    static final int VEHICLES_OFFSET = PLAYERS_OFFSET + MAX_PLAYERS * PLAYER_STRIDE;        // 21632
    static final int FPS_OFFSET      = VEHICLES_OFFSET + MAX_VEHICLES * VEHICLE_STRIDE;     // 22592
    static final int EXPIRY_OFFSET   = FPS_OFFSET + 4;                                       // 22596
    static final int SHM_SIZE        = EXPIRY_OFFSET + 48 + 12;                             // 22656

    // ── Toggle flags ───────────────────────────────────────────────────────
    public static volatile boolean drawLine      = true;
    public static volatile boolean drawSkeleton  = true;
    public static volatile boolean drawHealth    = true;
    public static volatile boolean drawDistance  = true;
    public static volatile boolean drawCount     = true;
    public static volatile boolean drawVehicle   = true;
    public static volatile boolean drawWatermark = true;
    public static volatile boolean drawExpiry    = true;

    // ── Hide from screenshot: when true, ESP surface is hidden from screenshots ─
    // Bug 7: set by OverlayService when Hide Recording toggle is enabled.
    public static volatile boolean hideFromScreenshot = false;
    // Ref to the running instance so OverlayService can call applySkipScreenshot
    public static volatile EspOverlay instance = null;

    // ── Match state: only render ESP when match is active ─────────────────
    private int  zeroPlayerFrames  = 0;
    private static final int ZERO_FRAMES_TO_CLEAR = 5; // ~165ms of no players = match ended

    // ── Expiry cache: once read non-empty, keep it — never blank it out ──
    // Loaded from expiry.txt on startup; updated from SHM when available.
    // Watermark+expiry shown whenever cachedExpiry is non-empty (no SHM gate).
    private String cachedExpiry = "";

    // ── Match cleared flag: true after needClear triggers, reset when match restarts ──
    private boolean matchCleared = false;

    // ── Startup grace: unused field kept for reference only ──────────────
    @SuppressWarnings("unused")
    private long serviceStartMs = 0;

    // ── Login success dialog ───────────────────────────────────────────────
    // showLoginDialog=true  → draw custom welcome dialog over everything
    // dialogDismissAt       → System.currentTimeMillis() when to auto-dismiss
    private volatile boolean showLoginDialog = false;
    private volatile boolean pendingClear    = false; // force canvas clear after dialog dismiss
    private long dialogDismissAt = 0;
    private static final long DIALOG_SHOW_MS = 2000; // 2 seconds auto-dismiss
    // Logo bitmap loaded once
    private android.graphics.Bitmap logoBitmap = null;
    // Dialog image bitmap (login_dialog.png from drawable)
    private android.graphics.Bitmap dialogBitmap = null;
    // White flash effect on OK tap
    private volatile boolean dialogFlash = false;
    private long dialogFlashEndMs = 0;
    private static final long FLASH_DURATION_MS = 120;

    // ── Internal state ─────────────────────────────────────────────────────
    private WindowManager  wm;
    private SurfaceView    surfaceView;
    private SurfaceHolder  holder;
    private WindowManager.LayoutParams overlayLp = null; // saved for touch toggle

    // ArkExternal fix: use actual screen dims, never canvas.getWidth/Height
    int screenW, screenH;

    private MappedByteBuffer buf;
    private RandomAccessFile  raf;
    private FileChannel       fc;

    private final Choreographer.FrameCallback frameCallback = this::onFrame;
    private long lastDrawMs = 0;
    private static final long FRAME_INTERVAL_MS = 33;
    private long lastSeq = -1;

    // ── DeadEye 3 paints ──────────────────────────────────────────────────
    private Paint mStrokePaint;
    private Paint mFilledPaint;
    private Paint mTextPaint;

    // ── Proportional scale ─────────────────────────────────────────────────
    private float mScale    = 1.0f;
    private float mTextSize = 22f;

    // ── Skeleton bone connections ──────────────────────────────────────────
    private static final int[][] BONE_PAIRS = {
        {0,1},{1,2},{2,3},{3,4},
        {0,5},{5,6},{6,7},
        {0,8},{8,9},{9,10},
        {4,11},{11,12},{12,13},
        {4,14},{14,15},{15,16},
    };

    private final float[]   bx = new float[MAX_BONES];
    private final float[]   by = new float[MAX_BONES];
    private final boolean[] bv = new boolean[MAX_BONES];
    private final RectF     rf = new RectF();

    // ═══════════════════════════════════════════════════════════════════════
    //  Service lifecycle
    // ═══════════════════════════════════════════════════════════════════════

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        serviceStartMs = System.currentTimeMillis(); // kept for reference
        startForegroundCompat();
        InitializePaints();
        initScreen();
        initSHM();
        loadExpiryFromFile(); // pre-load expiry so it's available before SHM has it
        loadLogoBitmap();
        loadDialogBitmap();
        startLoginFlagWatcher();
        addOverlayWindow();
    }

    private void startForegroundCompat() {
        final String CH_ID = "esp_overlay_ch";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CH_ID, "ESP Overlay", NotificationManager.IMPORTANCE_MIN);
            ch.setSound(null, null);
            ch.enableLights(false);
            ch.enableVibration(false);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
        }
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            nb = new Notification.Builder(this, CH_ID);
        else
            nb = new Notification.Builder(this);
        nb.setContentTitle("Vision ESP")
          .setSmallIcon(android.R.drawable.ic_dialog_info)
          .setOngoing(true);
        startForeground(0x45535000, nb.build());
    }

    @Override public int onStartCommand(Intent i, int f, int id) { return START_STICKY; }

    @Override
    public void onDestroy() {
        instance = null;
        Choreographer.getInstance().removeFrameCallback(frameCallback);
        if (surfaceView != null) {
            try { wm.removeView(surfaceView); } catch (Exception ignored) {}
            surfaceView = null;
        }
        closeSHM();
        super.onDestroy();
    }

    /**
     * Bug 7: Apply or remove screenshot-hide on the ESP SurfaceView.
     * Called from OverlayService when Hide Recording is toggled.
     * Uses the same SurfaceControl.Transaction setSkipScreenshot reflection as OverlayService.
     */
    public void applyEspSkipScreenshot(boolean on) {
        hideFromScreenshot = on;
        View v = surfaceView;
        if (v == null) return;
        v.post(() -> {
            try {
                Object vri = android.view.View.class.getMethod("getViewRootImpl").invoke(v);
                if (vri != null) {
                    Object sc2 = vri.getClass().getMethod("getSurfaceControl").invoke(vri);
                    if (sc2 != null) {
                        Class<?> scClass = Class.forName("android.view.SurfaceControl");
                        Class<?> txClass = Class.forName("android.view.SurfaceControl$Transaction");
                        Object tx = txClass.getConstructor().newInstance();
                        java.lang.reflect.Method setSkip =
                                txClass.getMethod("setSkipScreenshot", scClass, boolean.class);
                        setSkip.invoke(tx, sc2, on);
                        txClass.getMethod("apply").invoke(tx);
                    }
                }
            } catch (Throwable ignored) {}
        });
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  DeadEye paint initialisation
    // ═══════════════════════════════════════════════════════════════════════

    public void InitializePaints() {
        Typeface espFont = Typeface.MONOSPACE;
        try {
            int id = getResources().getIdentifier("araboto_normal", "font", getPackageName());
            if (id != 0) {
                Typeface tf = androidx.core.content.res.ResourcesCompat.getFont(this, id);
                if (tf != null) espFont = tf;
            }
        } catch (Exception ignored) {}

        mStrokePaint = new Paint();
        mStrokePaint.setStyle(Paint.Style.STROKE);
        mStrokePaint.setAntiAlias(true);
        mStrokePaint.setStrokeCap(Paint.Cap.ROUND);
        mStrokePaint.setStrokeJoin(Paint.Join.ROUND);

        mFilledPaint = new Paint();
        mFilledPaint.setStyle(Paint.Style.FILL);
        mFilledPaint.setAntiAlias(true);

        mTextPaint = new Paint();
        mTextPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        mTextPaint.setAntiAlias(true);
        mTextPaint.setTextAlign(Paint.Align.CENTER);
        mTextPaint.setStrokeWidth(1.1f);
        mTextPaint.setTypeface(espFont);
        mTextPaint.setFakeBoldText(true);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  DeadEye draw helpers
    // ═══════════════════════════════════════════════════════════════════════

    private void DrawLine(Canvas c, int a, int r, int g, int b, float w,
                          float x1, float y1, float x2, float y2) {
        mStrokePaint.setARGB(a, r, g, b);
        mStrokePaint.setStrokeWidth(w);
        c.drawLine(x1, y1, x2, y2, mStrokePaint);
    }

    private void DrawRect(Canvas c, int a, int r, int g, int b, float stroke,
                          float l, float t, float ri, float bo) {
        mStrokePaint.setARGB(a, r, g, b);
        mStrokePaint.setStrokeWidth(stroke);
        c.drawRect(l, t, ri, bo, mStrokePaint);
    }

    private void DrawFilledRect(Canvas c, int a, int r, int g, int b,
                                float l, float t, float ri, float bo) {
        mFilledPaint.setARGB(a, r, g, b);
        c.drawRect(l, t, ri, bo, mFilledPaint);
    }

    private void DrawFilledRoundRect(Canvas c, int a, int r, int g, int b,
                                     float l, float t, float ri, float bo, float rx) {
        mFilledPaint.setARGB(a, r, g, b);
        rf.set(l, t, ri, bo);
        c.drawRoundRect(rf, rx, rx, mFilledPaint);
    }

    /** Text with black drop-shadow offset +1.5px */
    private void DrawText(Canvas c, int a, int r, int g, int b, String txt,
                          float x, float y, float size) {
        mTextPaint.setTextSize(size);
        // shadow
        mTextPaint.setARGB(Math.min(a, 210), 0, 0, 0);
        c.drawText(txt, x + 1.5f, y + 1.5f, mTextPaint);
        // main
        mTextPaint.setARGB(a, r, g, b);
        c.drawText(txt, x, y, mTextPaint);
    }

    private void DrawCircle(Canvas c, int a, int r, int g, int b,
                            float cx, float cy, float radius, float stroke) {
        mStrokePaint.setARGB(a, r, g, b);
        mStrokePaint.setStrokeWidth(stroke);
        c.drawCircle(cx, cy, radius, mStrokePaint);
    }

    /** Corner-bracket box (DeadEye style) — arm = 22% of dimension */
    private void DrawCornerBox(Canvas c, int a, int r, int g, int b, float stroke,
                               float l, float t, float ri, float bo) {
        float cW = Math.min(28f, Math.max(8f, (ri - l) * 0.22f));
        float cH = Math.min(28f, Math.max(8f, (bo - t) * 0.22f));
        mStrokePaint.setARGB(a, r, g, b);
        mStrokePaint.setStrokeWidth(stroke);
        c.drawLine(l,  t,  l + cW, t,       mStrokePaint);
        c.drawLine(l,  t,  l,  t + cH,      mStrokePaint);
        c.drawLine(ri, t,  ri - cW, t,       mStrokePaint);
        c.drawLine(ri, t,  ri, t + cH,       mStrokePaint);
        c.drawLine(l,  bo, l + cW, bo,       mStrokePaint);
        c.drawLine(l,  bo, l,  bo - cH,      mStrokePaint);
        c.drawLine(ri, bo, ri - cW, bo,      mStrokePaint);
        c.drawLine(ri, bo, ri, bo - cH,      mStrokePaint);
    }

    /**
     * Health bar — HORIZONTAL, above box top (screenshot 2&3 style).
     * Thin bar sits just above bT. Full width = box width.
     *   Enemy: Cyan fill, black bg
     *   Bot:   Black fill, white outline, black bg
     */
    private void DrawHealthBar(Canvas c, float l, float t, float ri, float bo,
                               float health, boolean isBot) {
        float barH  = mScale * 3.5f;               // thin horizontal bar height
        float gap   = mScale * 5f;                 // gap above box top (moved up)
        float barT  = t - gap - barH;
        float barB  = t - gap;
        float barW  = ri - l;
        float hpW   = barW * Math.max(0f, Math.min(health, 1f));

        // black background border
        DrawFilledRect(c, 180, 0, 0, 0, l - 1f, barT - 1f, ri + 1f, barB + 1f);
        // dark empty bg
        DrawFilledRect(c, 120, 20, 20, 20, l, barT, ri, barB);
        // health fill
        if (isBot) {
            DrawFilledRect(c, 200, 30, 30, 30, l, barT, l + hpW, barB); // dark fill bot
        } else {
            DrawFilledRect(c, 230, 0, 255, 255, l, barT, l + hpW, barB); // cyan fill enemy
        }
        // outline: always draw white outline for bot, subtle for enemy
        if (isBot) {
            DrawRect(c, 220, 255, 255, 255, 1.0f, l, barT, ri, barB); // white outline visible
        } else {
            DrawRect(c, 100, 0, 200, 220, 0.7f, l, barT, ri, barB); // faint cyan outline
        }
    }

    private void ClearCanvas(Canvas c) {
        c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  Initialisation
    // ═══════════════════════════════════════════════════════════════════════

    private void initScreen() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        android.graphics.Point sz = new android.graphics.Point();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1)
            wm.getDefaultDisplay().getRealSize(sz);
        else {
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getMetrics(dm);
            sz.x = dm.widthPixels; sz.y = dm.heightPixels;
        }
        // Always landscape
        screenW = Math.max(sz.x, sz.y);
        screenH = Math.min(sz.x, sz.y);
    }

    private void addOverlayWindow() {
        surfaceView = new SurfaceView(this) {
            @Override protected void onDraw(Canvas canvas) {}
        };
        surfaceView.setZOrderOnTop(true);
        holder = surfaceView.getHolder();
        holder.setFormat(PixelFormat.TRANSPARENT);
        holder.addCallback(new SurfaceHolder.Callback() {
            @Override public void surfaceCreated(SurfaceHolder h) {
                Choreographer.getInstance().postFrameCallback(frameCallback);
            }
            @Override public void surfaceChanged(SurfaceHolder h, int f, int w, int h2) {}
            @Override public void surfaceDestroyed(SurfaceHolder h) {
                Choreographer.getInstance().removeFrameCallback(frameCallback);
            }
        });

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                screenW, screenH, 0, 0, overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.RGBA_8888);
        lp.gravity = android.view.Gravity.TOP | android.view.Gravity.START;
        lp.x = 0; lp.y = 0;

        // Screenshot protection
        try {
            java.lang.reflect.Field pf = WindowManager.LayoutParams.class.getDeclaredField("privateFlags");
            pf.setAccessible(true);
            pf.setInt(lp, 0x40);
        } catch (Exception ignored) {}

        overlayLp = lp; // save for touch toggle

        // Touch listener: tap anywhere to dismiss dialog
        surfaceView.setOnTouchListener((v, event) -> {
            if (!showLoginDialog) return false;
            if (event.getAction() == android.view.MotionEvent.ACTION_UP) {
                // Any tap dismisses the dialog immediately
                showLoginDialog = false;
                dialogFlash = false;
                pendingClear = true; // force canvas clear on next frame
                disableDialogTouch();
            }
            return true; // consume all touches while dialog is visible
        });

        wm.addView(surfaceView, lp);
    }

    private void initSHM() {
        String[] paths = {
            "/sdcard/Android/EspData.txt",
            "/storage/emulated/0/Android/EspData.txt",
            "/data/local/tmp/EspData.txt",
        };
        for (String p : paths) {
            if (tryOpenSHM(p)) return;
        }
        android.util.Log.e("VisionESP", "No SHM path opened");
    }

    private boolean tryOpenSHM(String path) {
        try {
            File f = new File(path);
            File parent = f.getParentFile();
            if (parent != null && !parent.exists()) //noinspection ResultOfMethodCallIgnored
                parent.mkdirs();
            raf = new RandomAccessFile(path, "rw");
            if (raf.length() < SHM_SIZE) raf.setLength(SHM_SIZE);
            fc  = raf.getChannel();
            buf = fc.map(FileChannel.MapMode.READ_WRITE, 0, SHM_SIZE);
            buf.order(ByteOrder.LITTLE_ENDIAN);
            android.util.Log.i("VisionESP", "SHM: " + path);
            return true;
        } catch (Exception e) { closeSHM(); return false; }
    }

    private void closeSHM() {
        buf = null;
        try { if (fc  != null) fc.close();  } catch (Exception ignored) {}
        try { if (raf != null) raf.close(); } catch (Exception ignored) {}
        fc = null; raf = null;
    }

    /**
     * Load expiry date from file saved by LoginActivity on login success.
     * Path: /storage/emulated/0/Android/obb/com.visionpro/expiry.txt
     * This pre-fills cachedExpiry so it is available even before SHM has the value,
     * and survives native dialog blanking the SHM expiry field.
     */
    private void loadExpiryFromFile() {
        String[] roots = {
            "/storage/emulated/0/Android/obb/com.visionpro/expiry.txt",
            "/sdcard/Android/obb/com.visionpro/expiry.txt",
        };
        for (String path : roots) {
            try {
                java.io.File ef = new java.io.File(path);
                if (!ef.exists() || ef.length() == 0) continue;
                java.io.FileInputStream fis = new java.io.FileInputStream(ef);
                byte[] buf2 = new byte[(int) Math.min(ef.length(), 64)];
                int n = fis.read(buf2);
                fis.close();
                if (n > 0) {
                    String val = new String(buf2, 0, n, "UTF-8").trim();
                    if (!val.isEmpty()) {
                        cachedExpiry = val;
                        android.util.Log.i("VisionESP", "Expiry from file: " + cachedExpiry);
                        return;
                    }
                }
            } catch (Exception ignored) {}
        }
    }

    /** Load app logo from drawable resources for use in the login success dialog. */
    private void loadLogoBitmap() {
        try {
            int resId = getResources().getIdentifier("logopng", "drawable", getPackageName());
            if (resId == 0) resId = getResources().getIdentifier("logo", "drawable", getPackageName());
            if (resId != 0) {
                android.graphics.drawable.Drawable d = androidx.core.content.res.ResourcesCompat
                        .getDrawable(getResources(), resId, null);
                if (d != null) {
                    int size = (int)(60f * (screenH / 1080f)); // ~60dp at 1080p
                    if (size < 40) size = 40;
                    logoBitmap = android.graphics.Bitmap.createBitmap(size, size,
                            android.graphics.Bitmap.Config.ARGB_8888);
                    android.graphics.Canvas tc = new android.graphics.Canvas(logoBitmap);
                    d.setBounds(0, 0, size, size);
                    d.draw(tc);
                }
            }
        } catch (Exception ignored) {}
    }

    /** Load login_dialog.png from drawable for the image-based dialog. */
    private void loadDialogBitmap() {
        try {
            int resId = getResources().getIdentifier("login_dialog", "drawable", getPackageName());
            if (resId != 0) {
                android.graphics.drawable.Drawable d = androidx.core.content.res.ResourcesCompat
                        .getDrawable(getResources(), resId, null);
                if (d != null) {
                    // Decode at full resolution — we'll scale when drawing
                    int w = d.getIntrinsicWidth();
                    int h = d.getIntrinsicHeight();
                    if (w <= 0) w = 1562;
                    if (h <= 0) h = 778;
                    dialogBitmap = android.graphics.Bitmap.createBitmap(w, h,
                            android.graphics.Bitmap.Config.ARGB_8888);
                    android.graphics.Canvas tc = new android.graphics.Canvas(dialogBitmap);
                    d.setBounds(0, 0, w, h);
                    d.draw(tc);
                }
            }
        } catch (Exception ignored) {}
    }

    /** Enable touch on overlay so user can tap OK on the dialog. */
    private void enableDialogTouch() {
        if (overlayLp == null || wm == null || surfaceView == null) return;
        try {
            overlayLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            wm.updateViewLayout(surfaceView, overlayLp);
        } catch (Exception ignored) {}
    }

    /** Restore NOT_TOUCHABLE so overlay doesn't block game input. */
    private void disableDialogTouch() {
        if (overlayLp == null || wm == null || surfaceView == null) return;
        try {
            overlayLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            wm.updateViewLayout(surfaceView, overlayLp);
        } catch (Exception ignored) {}
    }

    /**
     * Background thread: polls login_success.flag file every 300ms.
     * When found: set showLoginDialog=true, schedule auto-dismiss, delete flag.
     */
    private void startLoginFlagWatcher() {
        String[] flagPaths = {
            "/storage/emulated/0/Android/obb/com.visionpro/login_success.flag",
            "/sdcard/Android/obb/com.visionpro/login_success.flag",
        };
        Thread t = new Thread(() -> {
            while (true) {
                try {
                    for (String path : flagPaths) {
                        java.io.File f = new java.io.File(path);
                        if (f.exists()) {
                            // Consume the flag immediately
                            try { f.delete(); } catch (Exception ignored) {}
                            // Trigger dialog
                            showLoginDialog = true;
                            dialogFlash = false;
                            dialogDismissAt = System.currentTimeMillis() + DIALOG_SHOW_MS;
                            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                                showLoginDialog = false;
                                pendingClear = true; // force canvas clear on next frame
                                disableDialogTouch();
                            }, DIALOG_SHOW_MS);
                            // Enable touch so user can tap OK
                            new android.os.Handler(android.os.Looper.getMainLooper())
                                    .post(EspOverlay.this::enableDialogTouch);
                            android.util.Log.i("VisionESP", "Login success flag → dialog shown");
                            break;
                        }
                    }
                    Thread.sleep(300);
                } catch (InterruptedException ie) {
                    break;
                } catch (Exception ignored) {}
            }
        }, "LoginFlagWatcher");
        t.setDaemon(true);
        t.start();
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  Main draw loop
    // ═══════════════════════════════════════════════════════════════════════

    private void onFrame(long frameTimeNanos) {
        Choreographer.getInstance().postFrameCallback(frameCallback);
        if (holder == null || !holder.getSurface().isValid()) return;

        long now = System.currentTimeMillis();
        if (now - lastDrawMs < FRAME_INTERVAL_MS) return;
        lastDrawMs = now;

        // ── Dialog fast-path: if login dialog should show, draw it immediately ──
        // This is the ONLY reason we lock canvas without SHM data.
        if (showLoginDialog) {
            if (System.currentTimeMillis() >= dialogDismissAt) {
                showLoginDialog = false; // fallback only, Handler is primary
                dialogFlash = false;
                pendingClear = true;
                disableDialogTouch();
            } else {
                Canvas dc = holder.lockCanvas();
                if (dc != null) {
                    try {
                        ClearCanvas(dc);
                        final float sw = dc.getWidth(), sh = dc.getHeight();
                        mScale = sh / 1080f; mTextSize = sh / 50f;
                        drawLoginSuccessDialog(dc, sw, sh);
                    } finally { holder.unlockCanvasAndPost(dc); }
                }
                return;
            }
        }

        // ── Force-clear after dialog dismiss (ghost image fix) ───────────────
        if (pendingClear) {
            pendingClear = false;
            Canvas dc = holder.lockCanvas();
            if (dc != null) {
                try { ClearCanvas(dc); } finally { holder.unlockCanvasAndPost(dc); }
            }
            return;
        }

        // ── V15-style SeqLock: return early when no new SHM frame ─────────────
        // This preserves v15 behaviour exactly — no flicker from false matchActive=false.
        if (buf == null) return;

        int spinLimit = 100;
        long seqWrite;
        do {
            seqWrite = buf.getInt(0) & 0xFFFFFFFFL;
            if (spinLimit-- <= 0) return;
        } while ((seqWrite & 1L) != 0);

        if (seqWrite == lastSeq) return;
        lastSeq = seqWrite;

        // ── Sequential read ───────────────────────────────────────────────────
        ByteBuffer b = buf.duplicate().order(ByteOrder.LITTLE_ENDIAN);
        b.position(0);
        b.getInt(); b.getInt();   // seqWrite, seqRead
        b.getFloat(); b.getFloat(); // canvasW, canvasH — skip

        int playerCount  = b.getInt();
        int vehicleCount = b.getInt();
        int enemyCount   = b.getInt();
        int botCount     = b.getInt();

        if (playerCount  < 0 || playerCount  > MAX_PLAYERS)  playerCount  = 0;
        if (vehicleCount < 0 || vehicleCount > MAX_VEHICLES) vehicleCount = 0;

        // ── Match-active detection (v15 logic, unchanged) ─────────────────────
        boolean matchActive = (playerCount > 0 || vehicleCount > 0 || enemyCount > 0 || botCount > 0);
        if (!matchActive) {
            zeroPlayerFrames++;
        } else {
            zeroPlayerFrames = 0;
            matchCleared = false;
        }
        boolean needClear = (!matchActive && zeroPlayerFrames == ZERO_FRAMES_TO_CLEAR);
        if (needClear) {
            matchCleared = true;
            lastSeq = -1;
        }

        // ── Lock canvas ───────────────────────────────────────────────────────
        Canvas canvas = holder.lockCanvas();
        if (canvas == null) return;

        try {
            ClearCanvas(canvas);

            // sw/sh = actual overlay surface size — this is what we draw onto.
            final float sw = canvas.getWidth();
            final float sh = canvas.getHeight();
            mScale    = sh / 1080f;
            mTextSize = sh / 50f;

            // ── ESP: only when match is active AND not blocked ────────────────
            if (matchActive && !needClear && !matchCleared) {

            // ── Players ───────────────────────────────────────────────────
            for (int i = 0; i < playerCount; i++) {
                b.position(PLAYERS_OFFSET + i * PLAYER_STRIDE);

                float headX = b.getFloat() * sw;
                float headY = b.getFloat() * sh;
                float rootX = b.getFloat() * sw;
                float rootY = b.getFloat() * sh;

                for (int k = 0; k < MAX_BONES; k++) bx[k] = b.getFloat() * sw;
                for (int k = 0; k < MAX_BONES; k++) by[k] = b.getFloat() * sh;
                for (int k = 0; k < MAX_BONES; k++) bv[k] = b.get() != 0;
                b.position(b.position() + 3); // C++ struct pad after boneValid[17]

                float   health   = b.getFloat();
                float   distance = b.getFloat();
                boolean isBot    = b.get() != 0;
                boolean isVis    = b.get() != 0;
                boolean isKnk    = b.get() != 0;
                b.get(); // hasArmor

                // Read name (null-terminated)
                byte[] nb = new byte[32]; b.get(nb);
                StringBuilder nameSb = new StringBuilder();
                for (int k = 0; k < 32; k++) {
                    if (nb[k] == 0) break;
                    nameSb.append((char)(nb[k] & 0xFF));
                }
                String name = nameSb.toString().trim();

                // ══════════════════════════════════════════════════════════
                // ArkExternal-style: head/root anchored box
                // boxCX = midpoint between head and root for accurate centering
                // bT anchored at headY, bB at rootY — dynamic height
                // Skeleton: bone coords remapped into box (same as ArkExternal)
                // ══════════════════════════════════════════════════════════
                float bodyH = Math.abs(rootY - headY);
                // Box width proportional to body height (matches BGMI character ratio)
                float halfW = bodyH * 0.38f;
                float boxCX = (headX + rootX) / 2f;
                float bL    = boxCX - halfW;
                float bR    = boxCX + halfW;
                float bT    = headY;
                float bB    = rootY;

                // Colors
                // Bot: always black skeleton+lines
                // Enemy visible (LOS): white
                // Enemy hidden (cover): red
                // Knocked: orange
                int colA, colR, colG, colB;
                if (isKnk) {
                    colA=255; colR=255; colG=140; colB=0;   // orange knocked
                } else if (isBot) {
                    colA=220; colR=0;   colG=0;   colB=0;   // black bot
                } else if (isVis) {
                    colA=255; colR=255; colG=255; colB=255; // white visible enemy
                } else {
                    colA=255; colR=255; colG=30;  colB=30;  // red hidden enemy
                }

                float skelW = mScale * 1.1f;   // thin skeleton, slightly faded
                float boxSW = mScale * 1.0f;   // thin box edges

                // ── Skeleton: remap bone coords into box (ArkExternal approach) ──
                // fbx/fby declared at player scope so head-line can use them
                float[] fbx = new float[MAX_BONES];
                float[] fby = new float[MAX_BONES];
                boolean anyBone = false;
                {
                    float bMinX = Float.MAX_VALUE, bMaxX = -Float.MAX_VALUE;
                    float bMinY = Float.MAX_VALUE, bMaxY = -Float.MAX_VALUE;
                    for (int k = 0; k < MAX_BONES; k++) {
                        if (bv[k]) {
                            if (bx[k] < bMinX) bMinX = bx[k];
                            if (bx[k] > bMaxX) bMaxX = bx[k];
                            if (by[k] < bMinY) bMinY = by[k];
                            if (by[k] > bMaxY) bMaxY = by[k];
                            anyBone = true;
                        }
                    }
                    if (anyBone) {
                        float rX = Math.max(bMaxX - bMinX, 1f);
                        float rY = Math.max(bMaxY - bMinY, 1f);
                        float boxW2 = bR - bL;
                        float boxH2 = bB - bT;
                        for (int k = 0; k < MAX_BONES; k++) {
                            if (bv[k]) {
                                fbx[k] = bL + boxW2 * (bx[k] - bMinX) / rX;
                                fby[k] = bT + boxH2 * (by[k] - bMinY) / rY;
                            }
                        }
                    }
                }

                // Faded skeleton alpha (less dark/bright — screenshot style)
                int skelColA = (int)(colA * 0.72f); // ~72% of original alpha = faded
                if (drawSkeleton) {
                    if (anyBone) {
                        for (int[] pair : BONE_PAIRS) {
                            int a2 = pair[0], bIdx = pair[1];
                            if (a2 < MAX_BONES && bIdx < MAX_BONES && bv[a2] && bv[bIdx]) {
                                DrawLine(canvas, 100, 0, 0, 0, skelW + 0.8f,
                                         fbx[a2], fby[a2], fbx[bIdx], fby[bIdx]);
                                DrawLine(canvas, skelColA, colR, colG, colB, skelW,
                                         fbx[a2], fby[a2], fbx[bIdx], fby[bIdx]);
                            }
                        }
                        // Head line: neck bone → headY (bT)
                        if (bv[0]) {
                            DrawLine(canvas, 100, 0, 0, 0, skelW + 0.8f,
                                     fbx[0], fby[0], boxCX, bT);
                            DrawLine(canvas, skelColA, colR, colG, colB, skelW,
                                     fbx[0], fby[0], boxCX, bT);
                        }
                    }
                    // L-shaped corner box — WHITE, thin
                    DrawCornerBox(canvas, 150, 0, 0, 0, boxSW + 1.0f, bL, bT, bR, bB);
                    DrawCornerBox(canvas, 220, 255, 255, 255, boxSW, bL, bT, bR, bB);
                }

                // ── ESP line — from counter bottom → head (bT) ────────────
                if (drawLine) {
                    float lineStartY = 56f * mScale + 48f * mScale; // counter box bottom (boxTop + boxH)
                    float espLineW = mScale * 1.3f;
                    // Faded line: 170 alpha instead of 220
                    DrawLine(canvas, 120, 0, 0, 0, espLineW + 0.8f,
                             sw * 0.5f, lineStartY, boxCX, bT);
                    DrawLine(canvas, 170, colR, colG, colB, espLineW,
                             sw * 0.5f, lineStartY, boxCX, bT);
                }

                // ── Health bar — horizontal above box ────────────────────
                if (drawHealth) {
                    DrawHealthBar(canvas, bL, bT, bR, bB, health, isBot);
                }

                // ── Distance ONLY below feet — thin, white ────────────────
                // Name removed entirely. Only "20 M" format.
                if (drawDistance) {
                    float dSize = mTextSize * 0.72f;   // thinner/smaller
                    float footPad = mScale * 3f;
                    String dStr = (int) distance + " M";
                    float dY = bB + dSize + footPad;
                    // thin stroke for sharp text
                    mTextPaint.setTextSize(dSize);
                    mTextPaint.setStrokeWidth(0.6f);
                    mTextPaint.setTextAlign(android.graphics.Paint.Align.CENTER);
                    mTextPaint.setARGB(160, 0, 0, 0);
                    canvas.drawText(dStr, boxCX + 1f, dY + 1f, mTextPaint);
                    mTextPaint.setARGB(240, 255, 255, 255);
                    canvas.drawText(dStr, boxCX, dY, mTextPaint);
                    mTextPaint.setStrokeWidth(1.1f); // restore
                }
            }

            // ── Vehicles ──────────────────────────────────────────────────
            if (drawVehicle) {
                for (int i = 0; i < vehicleCount; i++) {
                    b.position(VEHICLES_OFFSET + i * VEHICLE_STRIDE);
                    float vx = b.getFloat() * sw;
                    float vy = b.getFloat() * sh;
                    float vd = b.getFloat();
                    b.get(); // hasEnemy
                    b.position(b.position() + 3); // pad
                    byte[] vn = new byte[32]; b.get(vn);
                    StringBuilder vsb = new StringBuilder();
                    for (int k = 0; k < 32; k++) {
                        if (vn[k] == 0) break;
                        vsb.append((char)(vn[k] & 0xFF));
                    }
                    String vName = vsb.toString().trim();
                    if (vName.isEmpty()) vName = "Vehicle";
                    String vText = vName + ": " + Math.round(vd) + "m";
                    DrawText(canvas, 200, 255, 255, 0, vText, vx, vy, mTextSize * 0.85f);
                }
            }

            // ── Enemy counter — two bigger boxes at screen center ─────────
            if (drawCount && (enemyCount > 0 || botCount > 0)) {
                float cntFont  = Math.min(mTextSize * 1.2f, 28f);
                float cx       = sw / 2f;
                float boxW     = 62f * mScale;   // wider than before
                float boxH     = 48f * mScale;   // taller than before
                float boxTop   = 56f * mScale;   // shifted down (was 46)
                float boxBot   = boxTop + boxH;

                // Left box: faded cyan-green (matches expiry text colour) | Right box: dark gray
                DrawFilledRect(canvas, 100, 0, 255, 230,        // faded cyan-green (enemy)
                        cx - boxW, boxTop, cx, boxBot);
                DrawFilledRect(canvas, 115, 25, 25, 25,          // dark gray (bot)
                        cx, boxTop, cx + boxW, boxBot);

                // Proper vertical centering via FontMetrics
                mTextPaint.setTextSize(cntFont);
                mTextPaint.setStrokeWidth(1.0f);
                Paint.FontMetrics fm = mTextPaint.getFontMetrics();
                float textH  = fm.descent - fm.ascent;
                float midY   = boxTop + (boxH - textH) / 2f - fm.ascent + 2f * mScale; // +2dp niche

                // Enemy count (cyan box, centered at cx - boxW/2)
                mTextPaint.setARGB(180, 0, 0, 0);
                canvas.drawText(String.valueOf(enemyCount), cx - boxW / 2f + 1f, midY + 1f, mTextPaint);
                mTextPaint.setARGB(245, 255, 255, 255);
                canvas.drawText(String.valueOf(enemyCount), cx - boxW / 2f, midY, mTextPaint);
                // Bot count (dark box, centered at cx + boxW/2)
                mTextPaint.setARGB(180, 0, 0, 0);
                canvas.drawText(String.valueOf(botCount), cx + boxW / 2f + 1f, midY + 1f, mTextPaint);
                mTextPaint.setARGB(245, 255, 255, 255);
                canvas.drawText(String.valueOf(botCount), cx + boxW / 2f, midY, mTextPaint);

                mTextPaint.setStrokeWidth(1.1f);
            }

            } // end if (matchActive)

            // ── Watermark (RIGHT) + Expiry (LEFT) ───────────────────────
            // Bug 1: shown as soon as cachedExpiry is non-empty (loaded from expiry.txt
            //        at startup, written by LoginActivity on login success).
            //        NO dependency on shmConnected or EspData.txt existing.
            // Also update cachedExpiry from SHM if SHM is available and has a value.
            if (buf != null) {
                try {
                    byte[] eb = new byte[48];
                    for (int k = 0; k < 48; k++) eb[k] = buf.get(EXPIRY_OFFSET + k);
                    StringBuilder esb = new StringBuilder();
                    for (int k = 0; k < 48; k++) {
                        if (eb[k] == 0) break;
                        esb.append((char)(eb[k] & 0xFF));
                    }
                    String freshExpiry = esb.toString().trim();
                    if (!freshExpiry.isEmpty()) cachedExpiry = freshExpiry;
                } catch (Exception ignored) {}
            }

            // Show watermark+expiry whenever we have an expiry value (from file or SHM)
            if (!cachedExpiry.isEmpty()) {
                float barSize = mTextSize * 1.1f;
                float barY    = sh - mScale * 12f;

                // ── Watermark: bottom RIGHT — shifted further left (Bug 5) ──
                if (drawWatermark) {
                    String wmTxt = "Vision Loader (v 4.6.0)";
                    mTextPaint.setTextSize(barSize);
                    mTextPaint.setTextAlign(android.graphics.Paint.Align.RIGHT);
                    mTextPaint.setFakeBoldText(false);
                    // Bug 5: further left — was mScale*60f, now mScale*120f
                    float wmX = sw - mScale * 120f;
                    mTextPaint.setStrokeWidth(1.5f);
                    mTextPaint.setARGB(160, 0, 0, 0);
                    canvas.drawText(wmTxt, wmX + 1f, barY + 1f, mTextPaint);
                    mTextPaint.setStrokeWidth(0.8f);
                    mTextPaint.setARGB(255, 255, 255, 0);
                    canvas.drawText(wmTxt, wmX, barY, mTextPaint);
                }

                // ── Expiry: bottom LEFT — shifted further right (Bug 5) ──
                if (drawExpiry) {
                    mTextPaint.setTextAlign(android.graphics.Paint.Align.LEFT);
                    mTextPaint.setTextSize(barSize);
                    mTextPaint.setFakeBoldText(false);
                    // Bug 5 v18: shifted further left — was mScale*150f, now mScale*50f
                    float exX = mScale * 50f;
                    mTextPaint.setStrokeWidth(1.5f);
                    mTextPaint.setARGB(160, 0, 0, 0);
                    canvas.drawText(cachedExpiry, exX + 1f, barY + 1f, mTextPaint);
                    mTextPaint.setStrokeWidth(0.8f);
                    mTextPaint.setARGB(255, 0, 255, 230);
                    canvas.drawText(cachedExpiry, exX, barY, mTextPaint);
                }

                // Restore paint defaults
                mTextPaint.setFakeBoldText(true);
                mTextPaint.setStrokeWidth(1.1f);
                mTextPaint.setTextAlign(android.graphics.Paint.Align.CENTER);
            } // end watermark+expiry block

            // ── Login success dialog (drawn ABOVE everything) ──────────────
            if (showLoginDialog) {
                if (System.currentTimeMillis() >= dialogDismissAt) {
                    showLoginDialog = false; // auto-dismiss after DIALOG_SHOW_MS
                } else {
                    drawLoginSuccessDialog(canvas, sw, sh);
                }
            }

        } finally {
            holder.unlockCanvasAndPost(canvas);
        }
    }

    /**
     * Draw a login-success dialog that matches the native Android AlertDialog style
     * (as seen in the UE4 MessageBox01 dialog — screenshot 2):
     *   • Pure-black background, small 4dp corner radius
     *   • Logo + "Vision" left-aligned in the title row (no coloured header band)
     *   • Left-aligned white body text
     *   • Solid gray horizontal divider (full width, no padding)
     *   • Blue "OK" text centred in the button row, transparent button bg
     */
    private void drawLoginSuccessDialog(Canvas canvas, float sw, float sh) {
        // ── Dim scrim behind dialog ───────────────────────────────────────
        mFilledPaint.setARGB(160, 0, 0, 0);
        canvas.drawRect(0, 0, sw, sh, mFilledPaint);

        // ── White flash effect on OK tap ──────────────────────────────────
        if (dialogFlash && System.currentTimeMillis() < dialogFlashEndMs) {
            // Flash the OK button area white
            float imgAspect = 1562f / 778f;
            float dH = sh * 0.375f;
            float dW = dH * imgAspect;
            float dL = (sw - dW) / 2f;
            float dT = (sh - dH) / 2f;
            float okLeft  = dL + dW * 0.25f;
            float okRight = dL + dW * 0.75f;
            float okTop   = dT + dH * 0.79f;
            float okBot   = dT + dH;
            mFilledPaint.setARGB(200, 255, 255, 255);
            canvas.drawRect(okLeft, okTop, okRight, okBot, mFilledPaint);
            mFilledPaint.setAlpha(255);
        }

        // ── Draw dialog image ─────────────────────────────────────────────
        if (dialogBitmap != null && !dialogBitmap.isRecycled()) {
            float imgAspect = (float) dialogBitmap.getWidth() / dialogBitmap.getHeight();
            // Native AlertDialog occupies ~37.5% screen height (measured from screenshot)
            float dH = sh * 0.375f;
            float dW = dH * imgAspect;
            float dL = (sw - dW) / 2f;
            float dT = (sh - dH) / 2f;
            android.graphics.Rect src = new android.graphics.Rect(0, 0,
                    dialogBitmap.getWidth(), dialogBitmap.getHeight());
            RectF dst = new RectF(dL, dT, dL + dW, dT + dH);
            mFilledPaint.setAlpha(255);
            canvas.drawBitmap(dialogBitmap, src, dst, mFilledPaint);
        } else {
            // Fallback: show simple text if image not loaded
            float sc = sh / 1080f;
            mTextPaint.setTextSize(sc * 32f);
            mTextPaint.setTextAlign(android.graphics.Paint.Align.CENTER);
            mTextPaint.setARGB(255, 255, 255, 255);
            canvas.drawText("Vision 4.6 — Login Success", sw / 2f, sh / 2f, mTextPaint);
            mTextPaint.setFakeBoldText(true);
            mTextPaint.setStrokeWidth(1.1f);
            mTextPaint.setTextAlign(android.graphics.Paint.Align.CENTER);
        }

        // Restore paint state
        mFilledPaint.setAlpha(255);
    }
}
