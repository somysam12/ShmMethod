package com.bgmi;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;

public class EspOverlay extends Service {

    private static final String TAG = "ArkESP";

    // ── SHM constants (match EspFrameData.h exactly) ─────────────────────────
    private static final int MAX_PLAYERS   = 100;
    private static final int MAX_VEHICLES  = 20;
    private static final int MAX_BONES     = 17;
    private static final int PLAYER_STRIDE = 216;
    private static final int VEHICLE_STRIDE= 48;
    private static final int FRAME_HEADER  = 32;
    private static final int PLAYERS_OFFSET  = FRAME_HEADER;
    private static final int VEHICLES_OFFSET = PLAYERS_OFFSET + MAX_PLAYERS * PLAYER_STRIDE;
    private static final int SHM_SIZE = VEHICLES_OFFSET + MAX_VEHICLES * VEHICLE_STRIDE + 64;

    private static final String[] SHM_PATHS = {
        "/storage/emulated/0/CrashLog/ark_esp_v1",
        "/storage/emulated/0/Android/data/com.bgmi/files/ark_esp_v1",
        "/data/data/com.bgmi/files/ark_esp_v1",
        "/data/local/tmp/ark_esp_v1"
    };

    // ── HUD SHM offsets (fps + expiryText live in original pad[64] area) ──────
    private static final int FPS_OFFSET    = VEHICLES_OFFSET + MAX_VEHICLES * VEHICLE_STRIDE; // +0
    private static final int EXPIRY_OFFSET = FPS_OFFSET + 4; // fps=int(4bytes), then char[48]

    // ╔══════════════════════════════════════════════════════════════════════╗
    // ║  USER CONFIG — edit these to customise all ESP visual settings      ║
    // ║  Change values here; no other code needs to be touched.             ║
    // ╚══════════════════════════════════════════════════════════════════════╝
    private static final boolean CFG_BOX_ON    = true;
    private static final String  CFG_VIS_C     = "#4DDD6A";  // visible enemy box
    private static final String  CFG_HIDE_C    = "#FF4444";  // in-cover enemy box
    private static final String  CFG_BOT_C     = "#ffffff";  // bot box
    private static final float   CFG_BOX_W     = 2.2f;  // box stroke thickness
    private static final int     CFG_BOX_A     = 220;

    private static final boolean CFG_SKEL_ON   = true;
    private static final float   CFG_SKEL_W    = 2f;    // skeleton bone thickness
    private static final int     CFG_SKEL_A    = 255;

    private static final boolean CFG_HP_ON     = true;
    private static final float   CFG_HP_H      = 21f;        // health bar height px (FIXED)
    private static final int     CFG_HP_A      = 255;
    private static final String  CFG_HP_G      = "#2ECC40";
    private static final String  CFG_HP_P      = "#C84D82";
    private static final String  CFG_HP_R      = "#DC2D2D";

    private static final boolean CFG_NAME_ON   = true;
    private static final float   CFG_NAME_SZ   = 20f;   // name/distance font size
    private static final String  CFG_NAME_C    = "#ffffff";

    private static final boolean CFG_LINE_ON   = true;
    private static final String  CFG_LINE_C    = "#00C8FF";
    private static final float   CFG_LINE_W    = 2.5f;  // ESP line thickness
    private static final int     CFG_LINE_A    = 255;

    private static final boolean CFG_CNT_ON    = true;
    private static final float   CFG_CNT_H     = 36f;   // counter pill height
    private static final float   CFG_CNT_R     = 26f;        // 0=rect, 26=pill
    private static final float   CFG_CNT_SZ    = 22f;   // counter font size
    private static final int     CFG_CNT_A     = 170;
    private static final String  CFG_CNT_E     = "#ff0000";
    private static final String  CFG_CNT_B     = "#00ffff";
    private static final String  CFG_CNT_CL    = "#27AE60";

    // ── HUD positions — change X/Y/font to reposition watermark, FPS, expiry ─
    // Watermark "ARK CHEAT BGMI" — bottom right
    private static final String WM1         = "ARK";          // yellow
    private static final String WM2         = " CHEAT";       // orange
    private static final String WM3         = " BGMI";        // white
    private static final float  WM_FONT     = 28f;   // watermark font — bigger
    private static final float  WM_Y_OFF    = 32f;            // px above bottom
    private static final float  WM_X_OFF    = 20f;   // px from right → shifts watermark LEFT
    // FPS indicator — top left
    private static final float  HUD_FPS_X   = 160f;  // FPS shifted RIGHT
    private static final float  HUD_FPS_Y   = 36f;
    private static final float  HUD_FPS_SZ  = 22f;   // FPS bigger
    // Expiry text — bottom left
    private static final float  HUD_EXP_X   = 120f;  // expiry shifted RIGHT
    private static final float  HUD_EXP_Y_OFF = 32f;         // px above bottom
    private static final float  HUD_EXP_SZ  = 20f;   // expiry bigger

    // ── Hide-ESP: screenshot protection via FLAG_SECURE ───────────────────────
    private static EspOverlay instance;
    private static volatile boolean sHideFlag = false;

    /** Called by OverlayService when user toggles Hide ESP */
    public static void setHideFlag(boolean hide) {
        sHideFlag = hide;
        new android.os.Handler(android.os.Looper.getMainLooper())
            .post(() -> { if (instance != null) instance.applyHideFlag(hide); });
    }

    /**
     * Hides the overlay from screenshots WITHOUT using FLAG_SECURE.
     *
     * FLAG_SECURE on a fullscreen overlay blocks the device's screenshot button
     * entirely (causes "Can't take screenshot due to security policy" error).
     *
     * Instead, use SurfaceControl.Transaction.setFlags() to set
     * eLayerSkipScreenshot (0x40) on just the overlay's surface.
     * This is the same flag native ANwCreator.hpp's eSkipScreenshot sets.
     *
     * Result: overlay is invisible in screenshots/recordings but physically
     * visible to the player on their screen — exactly like the menu does.
     */
    @android.annotation.SuppressLint("PrivateApi")
    private void applyHideFlag(boolean hide) {
        if (espView == null) return;
        try {
            // Get ViewRootImpl → mSurfaceControl via reflection
            java.lang.reflect.Field aiField =
                android.view.View.class.getDeclaredField("mAttachInfo");
            aiField.setAccessible(true);
            Object attachInfo = aiField.get(espView);
            if (attachInfo == null) { espLog("HIDE","attachInfo null"); return; }

            java.lang.reflect.Field vriField =
                attachInfo.getClass().getDeclaredField("mViewRootImpl");
            vriField.setAccessible(true);
            Object viewRootImpl = vriField.get(attachInfo);
            if (viewRootImpl == null) { espLog("HIDE","viewRootImpl null"); return; }

            android.view.SurfaceControl sc = null;
            for (String fname : new String[]{"mSurfaceControl","mBlastSurfaceControl"}) {
                try {
                    java.lang.reflect.Field f =
                        viewRootImpl.getClass().getDeclaredField(fname);
                    f.setAccessible(true);
                    Object obj = f.get(viewRootImpl);
                    if (obj instanceof android.view.SurfaceControl) {
                        sc = (android.view.SurfaceControl) obj;
                        break;
                    }
                } catch (NoSuchFieldException ignored) {}
            }
            if (sc == null) { espLog("HIDE","SurfaceControl field not found"); return; }

            // eLayerSkipScreenshot = 0x40 — same flag native ANwCreator eSkipScreenshot sets.
            // SurfaceControl.Transaction.setFlags() is @hide (not in public SDK) so we
            // must call it via reflection — direct call causes compile error.
            final int SKIP = 0x40;
            android.view.SurfaceControl.Transaction tx =
                new android.view.SurfaceControl.Transaction();

            java.lang.reflect.Method setFlagsM = null;
            for (java.lang.reflect.Method m : tx.getClass().getDeclaredMethods()) {
                if ("setFlags".equals(m.getName()) && m.getParameterTypes().length == 3) {
                    setFlagsM = m;
                    break;
                }
            }

            if (setFlagsM != null) {
                setFlagsM.setAccessible(true);
                setFlagsM.invoke(tx, sc, hide ? SKIP : 0, SKIP);
                tx.apply();
                espLog("HIDE", "eLayerSkipScreenshot=" + hide + " via reflection ✓");
            } else {
                espLog("HIDE", "setFlags not found — trying privateFlags fallback");
                applyPrivateFlagFallback(hide);
            }
        } catch (Throwable e) {
            espLog("HIDE", "SurfaceControl: " + e.getMessage() + " — trying fallback");
            applyPrivateFlagFallback(hide);
        }
    }

    /** Fallback: WindowManager.LayoutParams.privateFlags reflection */
    private void applyPrivateFlagFallback(boolean hide) {
        if (espView == null || wm == null) return;
        try {
            WindowManager.LayoutParams lp =
                (WindowManager.LayoutParams) espView.getLayoutParams();
            java.lang.reflect.Field pf =
                WindowManager.LayoutParams.class.getDeclaredField("privateFlags");
            pf.setAccessible(true);
            int flags = (int) pf.get(lp);
            if (hide) flags |= 0x00000040; // PRIVATE_FLAG_NO_SCREENSHOT
            else       flags &= ~0x00000040;
            pf.set(lp, flags);
            wm.updateViewLayout(espView, lp);
            espLog("HIDE", "privateFlags fallback=" + hide + " ✓");
        } catch (Throwable e) {
            espLog("HIDE", "privateFlags fallback: " + e.getMessage());
        }
    }

    // ── Feature flags ─────────────────────────────────────────────────────────
    public static volatile boolean drawLine     = false;
    public static volatile boolean drawSkeleton = false; // = "Box" in menu
    public static volatile boolean drawHealth   = false;
    public static volatile boolean drawDistance = false;
    public static volatile boolean drawName     = false;
    public static volatile boolean drawCount    = false;
    public static volatile boolean drawVehicle  = false;

    // ── State ─────────────────────────────────────────────────────────────────
    private WindowManager    wm;
    private EspView          espView;
    private MappedByteBuffer shmBuf;
    private RandomAccessFile shmFile;
    private int              lastSeq = -1;
    int                      screenW, screenH;
    private String           shmPathUsed = null;
    private int              dbgFramesRead = 0;
    private long             dbgLastLogMs  = 0;
    private static final long LOG_INTERVAL = 5000;

    // ── Paints (all pre-allocated — zero alloc in onDraw) ────────────────────
    private final Paint pBox     = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pHpBg    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pHpFg    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pName    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pNameSh  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pNameBg  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pDist    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pDistSh  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pLine    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pPillBg  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pPillBr  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pPillTx  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pVeh     = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pVehSh   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pSkel    = new Paint(Paint.ANTI_ALIAS_FLAG);

    // Standard BGMI skeleton bone connections (17 joints)
    private static final int[][] BONE_LINKS = {
        {0,1},{1,2},{2,3},{3,4},{4,5},   // spine chain
        {1,6},{6,7},{7,8},               // left arm
        {1,9},{9,10},{10,11},            // right arm
        {5,12},{12,13},{13,14},          // left leg
        {5,15},{15,16}                   // right leg
    };
    private final RectF rf       = new RectF();

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        instance = this;
        initPaints();
        initWindow();
        preTouchShmFile();
        openShm();
        startChoreographer();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        instance = null;
        if (espView != null && wm != null)
            try { wm.removeView(espView); } catch (Exception ignored) {}
        closeShm();
    }

    // ── Paint setup ───────────────────────────────────────────────────────────
    private void initPaints() {
        Typeface tf = null;
        try { tf = Typeface.createFromAsset(getAssets(), "fonts/vision_bold.ttf"); }
        catch (Exception ignored) {}
        final float SKEW = -0.20f; // italic/cursive skew

        // Corner bounding box
        pBox.setStyle(Paint.Style.STROKE); pBox.setStrokeWidth(CFG_BOX_W);
        pBox.setStrokeCap(Paint.Cap.ROUND);

        // Health bar
        pHpBg.setStyle(Paint.Style.FILL); pHpBg.setColor(Color.argb(160, 15, 15, 15));
        pHpFg.setStyle(Paint.Style.FILL);

        // Name — small (13sp) + italic skew
        pName.setTextSize(CFG_NAME_SZ); pName.setTextAlign(Paint.Align.CENTER);
        pName.setTextSkewX(SKEW); pName.setFakeBoldText(true);
        if (tf != null) pName.setTypeface(tf);

        pNameSh.setStyle(Paint.Style.STROKE); pNameSh.setStrokeWidth(2f);
        pNameSh.setColor(Color.argb(180, 0, 0, 0));
        pNameSh.setTextSize(CFG_NAME_SZ); pNameSh.setTextAlign(Paint.Align.CENTER);
        pNameSh.setTextSkewX(SKEW);
        if (tf != null) pNameSh.setTypeface(tf);

        pNameBg.setStyle(Paint.Style.FILL);

        // Distance — small (14sp) + italic skew
        pDist.setTextSize(16f); pDist.setTextAlign(Paint.Align.CENTER);
        pDist.setTextSkewX(SKEW);
        if (tf != null) pDist.setTypeface(tf);

        pDistSh.setStyle(Paint.Style.STROKE); pDistSh.setStrokeWidth(1.8f);
        pDistSh.setColor(Color.argb(160, 0, 0, 0));
        pDistSh.setTextSize(16f); pDistSh.setTextAlign(Paint.Align.CENTER);
        pDistSh.setTextSkewX(SKEW);
        if (tf != null) pDistSh.setTypeface(tf);

        // Skeleton bone lines
        pSkel.setStyle(Paint.Style.STROKE); pSkel.setStrokeWidth(CFG_SKEL_W);
        pSkel.setStrokeCap(Paint.Cap.ROUND);

        // ESP line
        pLine.setStyle(Paint.Style.STROKE); pLine.setStrokeWidth(CFG_LINE_W);

        // Counter pill
        pPillBg.setStyle(Paint.Style.FILL);
        pPillBr.setStyle(Paint.Style.STROKE); pPillBr.setStrokeWidth(1f);
        pPillBr.setColor(Color.argb(70, 255, 255, 255));
        pPillTx.setColor(Color.WHITE); pPillTx.setTextSize(CFG_CNT_SZ);
        pPillTx.setTextAlign(Paint.Align.CENTER); pPillTx.setFakeBoldText(true);
        pPillTx.setTextSkewX(SKEW);
        if (tf != null) pPillTx.setTypeface(tf);

        // Vehicle text — small (13sp)
        pVeh.setTextSize(CFG_NAME_SZ); pVeh.setTextAlign(Paint.Align.CENTER);
        pVeh.setTextSkewX(SKEW);
        if (tf != null) pVeh.setTypeface(tf);
        pVehSh.setStyle(Paint.Style.STROKE); pVehSh.setStrokeWidth(2f);
        pVehSh.setColor(Color.argb(200, 0, 0, 0));
        pVehSh.setTextSize(CFG_NAME_SZ); pVehSh.setTextAlign(Paint.Align.CENTER);
        pVehSh.setTextSkewX(SKEW);
        if (tf != null) pVehSh.setTypeface(tf);
    }

    // ── Window — always landscape ─────────────────────────────────────────────
    private void initWindow() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        android.graphics.Point sz = new android.graphics.Point();
        wm.getDefaultDisplay().getRealSize(sz);
        screenW = Math.max(sz.x, sz.y);
        screenH = Math.min(sz.x, sz.y);
        espLog("INIT", "Screen: " + screenW + "×" + screenH);
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            screenW, screenH, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.RGBA_8888);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 0; lp.y = 0;
        espView = new EspView(this);
        wm.addView(espView, lp);
    }

    // ── SHM ──────────────────────────────────────────────────────────────────
    private void preTouchShmFile() {
        new File("/storage/emulated/0/CrashLog").mkdirs();
        touch(new File("/storage/emulated/0/CrashLog/ark_esp_v1"));
        File ext = getExternalFilesDir(null);
        if (ext != null) { ext.mkdirs(); touch(new File(ext, "ark_esp_v1")); }
        getFilesDir().mkdirs();
    }
    private void touch(File f) {
        try { if (!f.exists()) { RandomAccessFile r = new RandomAccessFile(f,"rw"); r.setLength(SHM_SIZE); r.close(); }}
        catch (Exception e) { espLog("INIT","touch fail:"+f+" "+e.getMessage()); }
    }
    private void openShm() {
        List<String> paths = new ArrayList<>();
        paths.add("/storage/emulated/0/CrashLog/ark_esp_v1");
        File ext = getExternalFilesDir(null);
        if (ext != null) paths.add(ext.getAbsolutePath()+"/ark_esp_v1");
        paths.add(getFilesDir().getAbsolutePath()+"/ark_esp_v1");
        paths.add("/data/local/tmp/ark_esp_v1");
        espLog("INIT","Trying "+paths.size()+" SHM paths");
        for (String p : paths) {
            try {
                shmFile = new RandomAccessFile(p,"rw");
                if (shmFile.length() < SHM_SIZE) shmFile.setLength(SHM_SIZE);
                shmBuf = shmFile.getChannel().map(FileChannel.MapMode.READ_WRITE,0,SHM_SIZE);
                shmBuf.order(ByteOrder.LITTLE_ENDIAN);
                shmPathUsed = p; espLog("INIT","✔ SHM:"+p); return;
            } catch (Exception e) {
                espLog("INIT","✘ "+p+" "+e.getMessage());
                try { if (shmFile!=null) { shmFile.close(); shmFile=null; }} catch(Exception ig){}
                shmBuf=null;
            }
        }
        espLog("INIT","✘✘ ALL SHM paths failed");
    }
    private void closeShm() {
        try { if (shmFile!=null) shmFile.close(); } catch (Exception ignored) {}
        shmFile=null; shmBuf=null;
    }

    // ── Choreographer ─────────────────────────────────────────────────────────
    // Rate-limited to ~28fps (35ms interval):
    // Game writes SHM at 60fps but overlay only redraws every 35ms.
    // Effect: ESP position "snaps" every 35ms → looks like "slight shake then stable"
    // (same as socket-based cheats where TCP latency limits update rate).
    // At 60fps every frame would move, creating constant jitter with gyroscope.
    private long lastDrawMs = 0;
    private static final long DRAW_INTERVAL_MS = 35L; // ~28fps

    private void startChoreographer() {
        Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
            @Override public void doFrame(long ns) {
                boolean any = drawLine||drawSkeleton||drawHealth||drawDistance||drawName||drawCount||drawVehicle;
                if (espView!=null && shmBuf!=null && any) {
                    long now = System.currentTimeMillis();
                    int seq  = shmBuf.getInt(0);
                    // Only redraw when SHM has new data AND 35ms has passed
                    if (seq != lastSeq && now - lastDrawMs >= DRAW_INTERVAL_MS) {
                        lastSeq     = seq;
                        lastDrawMs  = now;
                        dbgFramesRead++;
                        espView.invalidate();
                    }
                }
                long now2 = System.currentTimeMillis();
                if (now2-dbgLastLogMs>=LOG_INTERVAL) { dbgLastLogMs=now2; logDiag(any); }
                Choreographer.getInstance().postFrameCallback(this);
            }
        });
    }

    // ── Color helpers ─────────────────────────────────────────────────────────
    /** Health fill color — uses CFG_HP_* colors with CFG_HP_A alpha */
    private int hpFadeColor(float hp) {
        String hex = hp > 0.65f ? CFG_HP_G : (hp > 0.35f ? CFG_HP_P : CFG_HP_R);
        int c = Color.parseColor(hex);
        return Color.argb(CFG_HP_A, Color.red(c), Color.green(c), Color.blue(c));
    }

    /** Parse hex color + apply alpha */
    private static int ca(String hex, int alpha) {
        int c = Color.parseColor(hex);
        return Color.argb(alpha, Color.red(c), Color.green(c), Color.blue(c));
    }

    // ── Corner box helper ─────────────────────────────────────────────────────
    private void cornerBox(Canvas c, float l, float t, float r, float b, Paint p) {
        float len = Math.min(r-l, b-t) * 0.25f;
        c.drawLine(l,t,l+len,t,p); c.drawLine(l,t,l,t+len,p);
        c.drawLine(r-len,t,r,t,p); c.drawLine(r,t,r,t+len,p);
        c.drawLine(l,b-len,l,b,p); c.drawLine(l,b,l+len,b,p);
        c.drawLine(r-len,b,r,b,p); c.drawLine(r,b,r,b-len,p);
    }

    // ── Pill counter helper ───────────────────────────────────────────────────
    private void pill(Canvas c, float cx, float cy, String txt, int fill) {
        float tw = pPillTx.measureText(txt);
        float ph = CFG_CNT_H, pw = Math.max(tw+44f, 75f);
        rf.set(cx-pw/2f, cy-ph/2f, cx+pw/2f, cy+ph/2f);
        pPillBg.setColor(fill);
        c.drawRoundRect(rf, CFG_CNT_R, CFG_CNT_R, pPillBg);
        c.drawRoundRect(rf, CFG_CNT_R, CFG_CNT_R, pPillBr);
        // Vertically center text using font metrics
        float textY = cy - (pPillTx.descent() + pPillTx.ascent()) / 2f;
        c.drawText(txt, cx, textY, pPillTx);
    }

    // ── Drawing ───────────────────────────────────────────────────────────────
    private class EspView extends View {
        EspView(android.content.Context ctx) { super(ctx); }

        @Override
        protected void onDraw(Canvas canvas) {
            if (shmBuf == null) return;

            ByteBuffer buf = shmBuf.duplicate().order(ByteOrder.LITTLE_ENDIAN);
            int seq;
            do { seq = buf.getInt(0); } while ((seq & 1) != 0); // seqlock

            buf.position(0);
            buf.getInt(); buf.getInt(); buf.getFloat(); buf.getFloat(); // skip header meta
            int playerCount = buf.getInt();
            int vehCount    = buf.getInt();
            int enemyCount  = buf.getInt();
            int botCount    = buf.getInt();

            if (buf.getInt(0) != seq) return;
            if (playerCount < 0 || playerCount > MAX_PLAYERS)  return;
            if (vehCount    < 0 || vehCount    > MAX_VEHICLES) return;

            float sw = screenW, sh = screenH;
            boolean anyEsp = drawLine||drawSkeleton||drawHealth||drawDistance||drawName;

            // ── PLAYERS ──────────────────────────────────────────────────────
            for (int i = 0; i < playerCount; i++) {
                buf.position(PLAYERS_OFFSET + i * PLAYER_STRIDE);

                float headX = buf.getFloat() * sw;
                float headY = buf.getFloat() * sh;
                float rootX = buf.getFloat() * sw;
                float rootY = buf.getFloat() * sh;

                float[] bx = new float[MAX_BONES], by = new float[MAX_BONES];
                boolean[] bv = new boolean[MAX_BONES];
                for (int b=0;b<MAX_BONES;b++) bx[b]=buf.getFloat()*sw;
                for (int b=0;b<MAX_BONES;b++) by[b]=buf.getFloat()*sh;
                for (int b=0;b<MAX_BONES;b++) bv[b]=buf.get()!=0;
                buf.position(buf.position()+3); // C++ struct padding after boneValid[17]

                float   health   = buf.getFloat();
                float   distance = buf.getFloat();
                boolean isBot    = buf.get()!=0;
                boolean isVis    = buf.get()!=0;
                boolean isKnk    = buf.get()!=0;
                buf.get(); // hasArmor
                byte[] nb = new byte[32]; buf.get(nb);
                String name = new String(nb).trim().replace("\0","");

                if (!anyEsp) continue;

                // ── FIXED BOX SIZE — same pixel size at ALL distances and zoom levels ──
                // User requirement: NO auto-scaling. 44x72px regardless of range.
                // Anchored at headY (head position), extends down by FBH.
                // boxCX = midpoint of head and root for accurate horizontal centering.
                final float FBW  = 44f;   // fixed box width  (px) — never changes
                final float FBH  = 72f;   // fixed box height (px) — never changes
                float boxCX = (headX + rootX) / 2f;
                float bL    = boxCX - FBW / 2f;
                float bR    = boxCX + FBW / 2f;
                float bT    = headY - 2f;       // anchor: just above head
                float bB    = bT + FBH;          // fixed height — NOT rootY
                float boxW  = FBW;               // alias for health bar fill width

                // Box color — from user config
                int boxColor;
                if (isKnk)      boxColor = Color.argb(230, 255, 160, 0);       // orange = knocked
                else if (isBot) boxColor = isVis ? ca(CFG_BOT_C, CFG_BOX_A) : Color.argb(160,160,160,160);
                else            boxColor = isVis ? ca(CFG_VIS_C, CFG_BOX_A) : ca(CFG_HIDE_C, CFG_BOX_A);

                // ── 1. ESP LINE: top-center → box top ─────────────────────
                if (drawLine && CFG_LINE_ON) {
                    pLine.setColor(isVis ? ca(CFG_LINE_C, CFG_LINE_A) : Color.argb(160,150,150,150));
                    canvas.drawLine(sw * 0.5f, 0f, boxCX, bT, pLine);
                }

                // ── 2. SKELETON — distance-independent (remapped into fixed box) ──
                // Native boneX/boneY are real screen coords that shrink at long range.
                // Fix: find the natural bounding rect of all valid bones, then
                // linearly remap each bone into the fixed box (bL→bR, bT→bB).
                // Result: skeleton always fills the same fixed pixel area regardless
                // of distance — identical to how box/health/name stay fixed.
                if (drawSkeleton) {
                    float bMinX = Float.MAX_VALUE, bMaxX = -Float.MAX_VALUE;
                    float bMinY = Float.MAX_VALUE, bMaxY = -Float.MAX_VALUE;
                    boolean anyBone = false;
                    for (int b = 0; b < MAX_BONES; b++) {
                        if (bv[b]) {
                            if (bx[b] < bMinX) bMinX = bx[b]; if (bx[b] > bMaxX) bMaxX = bx[b];
                            if (by[b] < bMinY) bMinY = by[b]; if (by[b] > bMaxY) bMaxY = by[b];
                            anyBone = true;
                        }
                    }
                    if (anyBone) {
                        float rX = Math.max(bMaxX - bMinX, 1f);
                        float rY = Math.max(bMaxY - bMinY, 1f);
                        float[] fbx = new float[MAX_BONES], fby = new float[MAX_BONES];
                        for (int b = 0; b < MAX_BONES; b++) {
                            if (bv[b]) {
                                fbx[b] = bL + FBW * (bx[b] - bMinX) / rX;
                                fby[b] = bT + FBH * (by[b] - bMinY) / rY;
                            }
                        }
                        pSkel.setColor(boxColor);
                        for (int[] link : BONE_LINKS) {
                            int f = link[0], t2 = link[1];
                            if (f < MAX_BONES && t2 < MAX_BONES && bv[f] && bv[t2])
                                canvas.drawLine(fbx[f], fby[f], fbx[t2], fby[t2], pSkel);
                        }
                    }
                }

                // ── 3. FULL RECTANGLE BOX ──────────────────────────────────
                if (drawSkeleton) {
                    pBox.setColor(boxColor);
                    pBox.setStrokeWidth(CFG_BOX_W);
                    canvas.drawRect(bL, bT, bR, bB, pBox);
                }

                // ── 4. HEALTH BAR + NAME — FIXED 20px height above box ─────
                // Health bar height is ALWAYS 20px regardless of distance.
                // Width matches box width (dynamic but proportional to body).
                if (drawHealth || drawSkeleton) {
                    final float FBarH = 20f; // FIXED — never scales
                    float hbT = bT - FBarH - 5f;  // 5px gap above box top
                    float hbB = bT - 1f;

                    // Dark background
                    pHpBg.setColor(Color.argb(185, 0, 0, 0));
                    canvas.drawRect(bL, hbT, bR, hbB, pHpBg);

                    // Health fill (faded color, variable width)
                    pHpFg.setColor(hpFadeColor(health));
                    canvas.drawRect(bL, hbT, bL + boxW * Math.max(health, 0f), hbB, pHpFg);

                    // Name text INSIDE bar — auto-fit if name too long
                    if (drawName) {
                        String dName = name.isEmpty() ? (isBot ? "Bot" : "?") : name;
                        // Auto-scale: reduce font until name fits in bar width
                        float fitSize = 16f;
                        pName.setTextSize(fitSize);
                        float maxW = boxW - 4f;
                        while (fitSize > 8f && pName.measureText(dName) > maxW) {
                            fitSize -= 1f;
                            pName.setTextSize(fitSize);
                        }
                        pNameSh.setTextSize(fitSize);
                        // Vertically center in bar
                        float textY = hbT + (FBarH - pName.descent() - pName.ascent()) * 0.5f;
                        canvas.drawText(dName, boxCX, textY, pNameSh);
                        pName.setColor(Color.parseColor(CFG_NAME_C));
                        canvas.drawText(dName, boxCX, textY, pName);
                        // Reset to default
                        pName.setTextSize(CFG_NAME_SZ);
                        pNameSh.setTextSize(CFG_NAME_SZ);
                    }
                }

                // ── 5. DISTANCE below box — "86 M" ─────────────────────────
                if (drawDistance) {
                    float dy = bB + 18f;
                    // Distance: YELLOW — thick text, always visible
                    pDist.setColor(Color.argb(240, 255, 215, 0));   // golden yellow
                    pDistSh.setColor(Color.argb(200, 0, 0, 0));
                    canvas.drawText((int) distance + " M", boxCX, dy, pDistSh);
                    canvas.drawText((int) distance + " M", boxCX, dy, pDist);
                }
            }

            // ── VEHICLES ─────────────────────────────────────────────────────
            if (drawVehicle) {
                for (int i = 0; i < vehCount; i++) {
                    buf.position(VEHICLES_OFFSET + i * VEHICLE_STRIDE);
                    float vx   = buf.getFloat()*sw, vy = buf.getFloat()*sh;
                    float vd   = buf.getFloat();
                    boolean he = buf.get()!=0;
                    byte[] vn  = new byte[32]; buf.get(vn);
                    String vName = new String(vn).trim().replace("\0","");
                    // Small text (13sp) — same as name
                    pVeh.setColor(he ? Color.argb(215,255,80,80) : Color.argb(215,77,221,106));
                    String vt = vName+"("+((int)vd)+"M)";
                    canvas.drawText(vt, vx, vy, pVehSh);
                    canvas.drawText(vt, vx, vy, pVeh);
                }
            }

            // ── COUNTER PILLS (purple + pink like SS1&2) ─────────────────────
            // Layout: [Enemy Count Pill] [Bot Count Pill]   or  [Clear Pill]
            if (drawCount && CFG_CNT_ON) {
                float pCY = 90f, pCX = sw/2f;

                if (enemyCount==0 && botCount==0) {
                    pill(canvas, pCX, pCY, "  Clear  ", ca(CFG_CNT_CL, CFG_CNT_A));

                } else if (enemyCount>0 && botCount>0) {
                    String eT="  "+enemyCount+"  ", bT2="  "+botCount+"  ";
                    float eW=Math.max(pPillTx.measureText(eT)+28f,55f);
                    float bW=Math.max(pPillTx.measureText(bT2)+28f,55f);
                    float tot=eW+8f+bW;
                    pill(canvas, pCX-tot/2f+eW/2f, pCY, eT,  ca(CFG_CNT_E, CFG_CNT_A));
                    pill(canvas, pCX+tot/2f-bW/2f, pCY, bT2, ca(CFG_CNT_B, CFG_CNT_A));

                } else if (enemyCount>0) {
                    pill(canvas, pCX, pCY, "  "+enemyCount+"  ", ca(CFG_CNT_E, CFG_CNT_A));
                } else {
                    pill(canvas, pCX, pCY, "  "+botCount+"  ", ca(CFG_CNT_B, CFG_CNT_A));
                }
            }

            // ── HUD: Watermark + FPS + Expiry (from SHM) ─────────────────────
            // Read fps and expiry from SHM (written by native PostRender)
            int  hudFps   = 0;
            String hudExp = "";
            if (shmBuf != null) {
                try {
                    hudFps = shmBuf.getInt(FPS_OFFSET);
                    byte[] eb = new byte[48];
                    for (int ei = 0; ei < 48; ei++) eb[ei] = shmBuf.get(EXPIRY_OFFSET + ei);
                    hudExp = new String(eb).trim().replace("\0", "");
                } catch (Throwable ignored) {}
            }

            // FPS — top left (cyan text)
            if (hudFps > 0) {
                String fpsTxt = "FPS: " + hudFps;
                pDist.setTextSize(HUD_FPS_SZ);
                pDist.setColor(Color.argb(230, 0, 255, 255)); // CYAN
                pDistSh.setTextSize(HUD_FPS_SZ);
                pDistSh.setColor(Color.argb(200, 0, 0, 0));
                pDist.setTextAlign(Paint.Align.LEFT);
                pDistSh.setTextAlign(Paint.Align.LEFT);
                canvas.drawText(fpsTxt, HUD_FPS_X + 1, HUD_FPS_Y + 1, pDistSh);
                canvas.drawText(fpsTxt, HUD_FPS_X,     HUD_FPS_Y,     pDist);
                pDist.setTextAlign(Paint.Align.CENTER);
                pDistSh.setTextAlign(Paint.Align.CENTER);
                pDist.setTextSize(CFG_NAME_SZ); pDistSh.setTextSize(CFG_NAME_SZ);
            }

            // Expiry — bottom left (red text)
            if (!hudExp.isEmpty()) {
                float expY = sh - HUD_EXP_Y_OFF;
                pDist.setTextSize(HUD_EXP_SZ); pDistSh.setTextSize(HUD_EXP_SZ);
                pDist.setColor(Color.argb(230, 255, 50, 50)); // RED
                pDist.setTextAlign(Paint.Align.LEFT); pDistSh.setTextAlign(Paint.Align.LEFT);
                canvas.drawText(hudExp, HUD_EXP_X + 1, expY + 1, pDistSh);
                canvas.drawText(hudExp, HUD_EXP_X,     expY,     pDist);
                pDist.setTextAlign(Paint.Align.CENTER); pDistSh.setTextAlign(Paint.Align.CENTER);
                pDist.setTextSize(CFG_NAME_SZ); pDistSh.setTextSize(CFG_NAME_SZ);
            }

            // Watermark "ARK CHEAT BGMI" — bottom right (3-color)
            {
                float wmY   = sh - WM_Y_OFF;
                pName.setTextSize(WM_FONT); pNameSh.setTextSize(WM_FONT);
                pName.setFakeBoldText(true);
                // measure each part
                pName.setColor(Color.WHITE);
                float w1 = pName.measureText(WM1);
                float w2 = pName.measureText(WM2);
                float w3 = pName.measureText(WM3);
                float wmX = sw - WM_X_OFF - w1 - w2 - w3;
                pName.setTextAlign(Paint.Align.LEFT); pNameSh.setTextAlign(Paint.Align.LEFT);
                // shadows
                canvas.drawText(WM1, wmX+1,       wmY+1, pNameSh);
                canvas.drawText(WM2, wmX+w1+1,    wmY+1, pNameSh);
                canvas.drawText(WM3, wmX+w1+w2+1, wmY+1, pNameSh);
                // colored text
                pName.setColor(Color.argb(255,255,220,0));   // ARK = yellow
                canvas.drawText(WM1, wmX, wmY, pName);
                pName.setColor(Color.argb(255,255,120,0));   // CHEAT = orange
                canvas.drawText(WM2, wmX+w1, wmY, pName);
                pName.setColor(Color.WHITE);                  // BGMI = white
                canvas.drawText(WM3, wmX+w1+w2, wmY, pName);
                // reset
                pName.setTextAlign(Paint.Align.CENTER); pNameSh.setTextAlign(Paint.Align.CENTER);
                pName.setTextSize(CFG_NAME_SZ); pNameSh.setTextSize(CFG_NAME_SZ);
            }
        }
    }

    // ── Logger ────────────────────────────────────────────────────────────────
    static void espLog(String sub, String msg) {
        android.util.Log.i("ArkESP/"+sub, msg);
        try { ContainerLogger.li("ArkESP/"+sub, msg); } catch (Throwable ignored) {}
    }

    private void logDiag(boolean any) {
        String f="Line="+(drawLine?"ON":"off")+" Box="+(drawSkeleton?"ON":"off")
            +" HP="+(drawHealth?"ON":"off")+" Dist="+(drawDistance?"ON":"off")
            +" Name="+(drawName?"ON":"off")+" Cnt="+(drawCount?"ON":"off")
            +" Veh="+(drawVehicle?"ON":"off");
        espLog("FLAGS",f);
        if (shmBuf==null) {
            espLog("SHM","✘ shmBuf=NULL "+(shmPathUsed==null?"(no path)":shmPathUsed));
        } else {
            int sw2=shmBuf.getInt(0),pc=shmBuf.getInt(16),ec=shmBuf.getInt(24),bc=shmBuf.getInt(28);
            espLog("SHM","✔ "+shmPathUsed+" seqW="+sw2+" players="+pc
                +" enemies="+ec+" bots="+bc+" frames="+dbgFramesRead+" anyFeat="+any);
            if (sw2==0) espLog("SHM","⚠ seqWrite=0 — native never wrote");
            if (pc==0&&ec==0) espLog("SHM","⚠ playerCount=0 — ESP loop not filling");
        }
    }
}
