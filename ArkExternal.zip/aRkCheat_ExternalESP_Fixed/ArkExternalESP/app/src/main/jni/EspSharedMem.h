#pragma once
// ════════════════════════════════════════════════════════════════════════════
// EspSharedMem.h — Native side shared memory writer
//
// FIX: memfd_create creates an anonymous fd with NO filesystem path.
// Java (EspOverlay, different process) cannot open it by name.
// Solution: always use a regular file at a path both processes can access.
// ════════════════════════════════════════════════════════════════════════════

#include "EspFrameData.h"
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <android/log.h>
#include <cstring>
#include <cstdio>

#define SHM_LOG "ArkSHM"
#define SHMLOGI(...) __android_log_print(ANDROID_LOG_INFO,  SHM_LOG, __VA_ARGS__)
#define SHMLOGE(...) __android_log_print(ANDROID_LOG_ERROR, SHM_LOG, __VA_ARGS__)

// Paths tried in order — Java side must try the same paths in same order
// Primary: /data/local/tmp/ — world-writable on most Android versions
// Fallback: /dev/shm/ — some custom ROMs
static const char* ARK_SHM_PATHS[] = {
    "/data/local/tmp/ark_esp_v1",
    "/dev/shm/ark_esp_v1",
    nullptr
};

static ArkEspFrame* g_ShmFrame   = nullptr;
static int          g_ShmFd      = -1;
static bool         g_ShmReady   = false;
static const char*  g_ShmPathUsed = nullptr;

// ── Init: call once from JNI_OnLoad or first PostRender ──────────────────────
static bool ShmESP_Init() {
    if (g_ShmReady) return true;

    // NOTE: memfd_create is intentionally NOT used here.
    // memfd_create creates an anonymous fd with no filesystem path —
    // EspOverlay.java (running in the loader process) cannot open it.
    // Regular file: both BGMI's virtual process and loader process share
    // the same Linux UID, so a world-accessible temp file works for both.

    for (int i = 0; ARK_SHM_PATHS[i] != nullptr; i++) {
        const char* path = ARK_SHM_PATHS[i];
        int fd = open(path, O_CREAT | O_RDWR, 0666);
        if (fd < 0) {
            SHMLOGE("SHM open failed for %s: errno=%d", path, errno);
            continue;
        }

        if (ftruncate(fd, (off_t)ARK_SHM_SIZE) < 0) {
            SHMLOGE("ftruncate failed for %s: errno=%d", path, errno);
            close(fd);
            continue;
        }

        void* ptr = mmap(nullptr, ARK_SHM_SIZE,
                         PROT_READ | PROT_WRITE,
                         MAP_SHARED, fd, 0);
        if (ptr == MAP_FAILED) {
            SHMLOGE("mmap failed for %s: errno=%d", path, errno);
            close(fd);
            continue;
        }

        g_ShmFd      = fd;
        g_ShmFrame   = (ArkEspFrame*)ptr;
        g_ShmPathUsed = path;
        memset(g_ShmFrame, 0, ARK_SHM_SIZE);
        g_ShmReady   = true;
        SHMLOGI("SHM ready: %s size=%zu", path, ARK_SHM_SIZE);
        return true;
    }

    SHMLOGE("SHM: ALL paths failed — external ESP overlay will not draw");
    return false;
}

// ── Write one ESP frame — called at end of PostRender ────────────────────────
static void ShmESP_Write(const ArkEspFrame& frame) {
    if (!g_ShmReady || !g_ShmFrame) return;

    // SeqLock: mark write in progress (odd = busy)
    g_ShmFrame->seqWrite |= 1u;
    __sync_synchronize();

    memcpy(&g_ShmFrame->canvasW, &frame.canvasW,
           sizeof(ArkEspFrame) - offsetof(ArkEspFrame, canvasW));

    __sync_synchronize();
    // Mark write done: increment to next even value
    g_ShmFrame->seqWrite = (g_ShmFrame->seqWrite + 1u) & ~1u;
}

// ── Cleanup ───────────────────────────────────────────────────────────────────
static void ShmESP_Destroy() {
    if (g_ShmFrame)   { munmap(g_ShmFrame, ARK_SHM_SIZE); g_ShmFrame = nullptr; }
    if (g_ShmFd >= 0) {
        close(g_ShmFd);
        // Unlink the file so it's cleaned up
        if (g_ShmPathUsed) unlink(g_ShmPathUsed);
        g_ShmFd = -1;
    }
    g_ShmReady    = false;
    g_ShmPathUsed = nullptr;
}
