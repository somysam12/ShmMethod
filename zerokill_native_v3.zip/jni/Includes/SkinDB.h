#pragma once
#include <vector>

// ═══════════════════════════════════════════════════════════════
//  SKIN ATTACHMENT DATABASE
//  SkinEntry: maps a slot item ID to its attachment skin code
//  SkinDB_GetAttachments: returns attachment entries for a given
//  gun skin code using the computed formula:
//    attach_base = (gun_skin_code / 10) * 10  → strip last digit
//    slot_offset per attachment slot → attach_base + offset
// ═══════════════════════════════════════════════════════════════

struct SkinEntry {
    int       slot_item_id;   // synData key (attachment slot ID)
    long long code;           // attachment skin code value
};

// Slot item IDs for common attachment slots
#define SLOT_4X_SCOPE       203004
#define SLOT_3X_SCOPE       203014
#define SLOT_2X_SCOPE       203003
#define SLOT_HOLO           203002
#define SLOT_RED_DOT        203001
#define SLOT_FLASH_HIDER    201010
#define SLOT_COMPENSATOR    201009
#define SLOT_SUPPRESSOR     201011
#define SLOT_EXT_MAG        204011
#define SLOT_QD_MAG         204012
#define SLOT_EXT_QD_MAG     204013
#define SLOT_HALF_GRIP      202001
#define SLOT_THUMB_GRIP     202003
#define SLOT_VERT_GRIP      202004
#define SLOT_ANGLED_GRIP    202005
#define SLOT_LIGHT_GRIP     202006
#define SLOT_STOCK          205003
#define SLOT_CHEEK_PAD      205004
#define SLOT_TACTICAL_STOCK 205006

// ── Static attachment pool (allocated once, avoids repeated allocs) ──────────
static SkinEntry s_attachBuf[20];

// ── Returns attachment entries computed from gun_skin_code ───────────────────
// Formula: attach_prefix comes from upper digits of gun_skin_code
//   e.g. gun_skin_code = 1101001128 (AKM Ghillie Dragon Lv7)
//        attach series  = 1010011220 base → 1010011222..1010011234
// For codes that don't follow the standard pattern, returns empty vector.
inline std::vector<const SkinEntry*> SkinDB_GetAttachments(long long gun_skin_code) {
    std::vector<const SkinEntry*> result;

    if (gun_skin_code <= 0) return result;

    // Standard attachment code pattern:
    // gun skin code: 11XXXXX YYY  (11 + 5-digit gun prefix + 3-digit variant)
    // attach code:   10XXXXX YYY0 + slot_offset
    // where XXXXX = gun base digits, YYY = variant index

    // Extract components
    long long prefix = gun_skin_code / 1000;       // strip last 3 digits
    long long variant = gun_skin_code % 1000;      // last 3 digits = variant

    // Convert skin prefix (11XXXXX) to attach prefix (10XXXXX)
    // e.g. 1101001 → 1001001 (replace leading 11 with 10)
    long long attach_prefix = prefix - 1000000LL;  // 11xxxxx → 10xxxxx
    if (attach_prefix <= 0) return result;

    long long attach_base = attach_prefix * 10000LL + variant * 10LL;

    // Standard slot offsets (verified against KC_GunMaps.h)
    static const struct { int slotID; int offset; } kSlots[] = {
        { SLOT_4X_SCOPE,    2 },
        { SLOT_3X_SCOPE,    3 },
        { SLOT_2X_SCOPE,    4 },
        { SLOT_HOLO,        5 },
        { SLOT_RED_DOT,     6 },
        { SLOT_EXT_MAG,     7 },
        { SLOT_QD_MAG,      8 },
        { SLOT_EXT_QD_MAG,  9 },
        { SLOT_FLASH_HIDER, 12 },
        { SLOT_COMPENSATOR, 13 },
        { SLOT_SUPPRESSOR,  14 },
        { SLOT_HALF_GRIP,   15 },
        { SLOT_THUMB_GRIP,  16 },
        { SLOT_VERT_GRIP,   17 },
        { SLOT_ANGLED_GRIP, 18 },
        { SLOT_LIGHT_GRIP,  19 },
        { SLOT_STOCK,       20 },
        { SLOT_CHEEK_PAD,   21 },
        { SLOT_TACTICAL_STOCK, 22 },
    };

    int count = 0;
    for (auto& s : kSlots) {
        if (count >= 20) break;
        s_attachBuf[count].slot_item_id = s.slotID;
        s_attachBuf[count].code         = attach_base + s.offset;
        result.push_back(&s_attachBuf[count]);
        count++;
    }

    return result;
}
